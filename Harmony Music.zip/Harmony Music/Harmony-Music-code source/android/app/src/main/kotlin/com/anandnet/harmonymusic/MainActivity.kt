package com.anandnet.harmonymusic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
