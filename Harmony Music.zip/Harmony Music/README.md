
# Harmony Music
Une application de streaming musical réalisée avec Flutter

# Fonctionnalités
* Capacité de lire des chansons depuis Youtube/Youtube Music.
* Mise en cache des chansons en lecture
* Prise en charge de la fonctionnalité radio
* Lecture de musique en arrière-plan
* Création de listes de lecture et prise en charge des signets
* Prise en charge des signets d'artistes et d'albums
* Importation de chansons, listes de lecture, albums et artistes via le partage depuis Ytube/Ytube Music.
* Contrôle de la qualité du streaming
* Prise en charge du téléchargement de chansons
* Support linguistique
* Ignorer les silences
* Thème dynamique
* Flexibilité pour passer entre la barre de navigation inférieure et latérale
* Prise en charge de l'égaliseur
* Support Android Auto
* Prise en charge des paroles synchronisées et non formatées
* Minuterie de sommeil
* Pas de publicité
* Aucune connexion requise
* Intégration de listes de lecture Piped

